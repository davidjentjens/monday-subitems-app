// import { useState } from 'react'
import { Subitem } from 'src/interfaces'

interface StatusCellProps {
  subitem: Subitem
  columnId: string
}

export const StatusCell: React.FC<StatusCellProps> = () =>
  /* {
     subitem,
  columnId, 
  }, */
  {
    /* const [dialogIsOpen, setDialogIsOpen] = useState(false)
  const [statusId, setStatusId] = useState<number | null>(
    subitem[columnId]?.value.index ? subitem[columnId]?.value.index : null,
  ) */

    return <div></div>
  }
